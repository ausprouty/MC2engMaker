export default[

    {
        path: "/M2/eng/multiply3/Index",
        name: "eng-multiply3-index",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3Index.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply3intro1",
        name: "eng-multiply3intro1",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3intro1.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply301",
        name: "eng-multiply301",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply301.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply302",
        name: "eng-multiply302",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply302.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply303",
        name: "eng-multiply303",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply303.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply304",
        name: "eng-multiply304",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply304.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply305",
        name: "eng-multiply305",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply305.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply306",
        name: "eng-multiply306",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply306.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply307",
        name: "eng-multiply307",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply307.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply308",
        name: "eng-multiply308",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply308.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply309",
        name: "eng-multiply309",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply309.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply310",
        name: "eng-multiply310",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply310.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply311",
        name: "eng-multiply311",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply311.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply312",
        name: "eng-multiply312",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply312.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply313",
        name: "eng-multiply313",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply313.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply3intro2",
        name: "eng-multiply3intro2",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3intro2.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply314",
        name: "eng-multiply314",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply314.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply315",
        name: "eng-multiply315",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply315.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply316",
        name: "eng-multiply316",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply316.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply317",
        name: "eng-multiply317",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply317.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply318",
        name: "eng-multiply318",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply318.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply319",
        name: "eng-multiply319",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply319.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply320",
        name: "eng-multiply320",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply320.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply321",
        name: "eng-multiply321",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply321.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply322",
        name: "eng-multiply322",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply322.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply323",
        name: "eng-multiply323",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply323.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply3intro3",
        name: "eng-multiply3intro3",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3intro3.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply324",
        name: "eng-multiply324",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply324.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply325",
        name: "eng-multiply325",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply325.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply326",
        name: "eng-multiply326",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply326.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply327",
        name: "eng-multiply327",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply327.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply328",
        name: "eng-multiply328",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply328.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply329",
        name: "eng-multiply329",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply329.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply330",
        name: "eng-multiply330",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply330.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply3intro4",
        name: "eng-multiply3intro4",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3intro4.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply331",
        name: "eng-multiply331",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply331.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply332",
        name: "eng-multiply332",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply332.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply333",
        name: "eng-multiply333",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply333.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply334",
        name: "eng-multiply334",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply334.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply335",
        name: "eng-multiply335",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply335.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply336",
        name: "eng-multiply336",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply336.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply3intro5",
        name: "eng-multiply3intro5",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3intro5.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply337",
        name: "eng-multiply337",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply337.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply338",
        name: "eng-multiply338",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply338.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply339",
        name: "eng-multiply339",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply339.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply340",
        name: "eng-multiply340",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply340.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply341",
        name: "eng-multiply341",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply341.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply342",
        name: "eng-multiply342",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply342.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply3intro6",
        name: "eng-multiply3intro6",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3intro6.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply343",
        name: "eng-multiply343",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply343.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply344",
        name: "eng-multiply344",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply344.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply345",
        name: "eng-multiply345",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply345.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply346",
        name: "eng-multiply346",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply346.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply347",
        name: "eng-multiply347",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply347.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply348",
        name: "eng-multiply348",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply348.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply349",
        name: "eng-multiply349",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply349.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply350",
        name: "eng-multiply350",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply350.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply351",
        name: "eng-multiply351",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply351.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply352",
        name: "eng-multiply352",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply352.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply353",
        name: "eng-multiply353",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply353.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply354",
        name: "eng-multiply354",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply354.vue"
          );
        },
    },

    {
        path: "/M2/eng/multiply3/multiply3end",
        name: "eng-multiply3end",
        component: function () {
          return import(
            /* webpackChunkName: "prototype" */ "../views/M2/eng/multiply3/EngMultiply3end.vue"
          );
        },
    },
];